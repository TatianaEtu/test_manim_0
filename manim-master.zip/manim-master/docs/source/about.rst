About
=====

Animating technical concepts is traditionally pretty tedious, since it can be
difficult to make the animations precise enough to convey them accurately.
``Manim`` uses Python to generate animations programmatically, which makes it
possible to specify exactly how each one should run.

This project is still very much a work in progress, but I hope that the
information here will make it easier for newcomers to get started using
``Manim``.
